# Online_Voting_System

>> You have to first register yourself on the system as an political party or voter (then your data have been saved )
>>  Login in to your account then you can access your dashboard where you can also find how many votes  political party is having right now,
>>  you can also voye to some political party as your choice after that you are not able to vote any party (valid only for once)

Hosted Website:- https://systemvoting2022.000webhostapp.com/

Tools used:- CSS3, javascript, php, mysql, xampp, HTML
